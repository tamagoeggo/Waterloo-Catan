#ifndef _TYPE_H_
#define _TYPE_H_

enum class Type {Achievement, Assignment, Midterm, Exam, None};

#endif
