#include "subject.h"

// virtual dtor
Subject::~Subject(){}
