#ifndef _COMPLETION_H_
#define _COMPLETION_H_

enum class Completion {Assignment, Midterm, Exam, None};

#endif
